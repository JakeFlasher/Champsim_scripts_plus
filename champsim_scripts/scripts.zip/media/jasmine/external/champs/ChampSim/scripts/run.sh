sleep 3h
./test3.sh
