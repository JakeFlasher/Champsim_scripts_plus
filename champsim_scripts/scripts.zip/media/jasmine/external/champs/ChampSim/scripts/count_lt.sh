la -la dpc3_traces/*/400M/*.out | awk -v MAX=1500 '/^-/ && $5 <= MAX { print $NF }' | w
c -l
